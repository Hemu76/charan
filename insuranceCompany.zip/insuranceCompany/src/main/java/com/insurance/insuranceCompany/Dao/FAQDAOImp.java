package com.insurance.insuranceCompany.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.insuranceCompany.model.FAQ;
import com.insurance.insuranceCompany.rowMapper.FAQRowMapper;


@Component
public class FAQDAOImp implements FAQDAO{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private String SQL_GET_FAQS = "select * from healthinsurancefaqs";

	@Override
	public List<FAQ> getAllFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_FAQS, new FAQRowMapper());
	}
}
