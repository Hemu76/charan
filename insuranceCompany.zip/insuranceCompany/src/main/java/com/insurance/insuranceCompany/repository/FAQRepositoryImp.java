package com.insurance.insuranceCompany.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.insuranceCompany.Dao.FAQDAO;
import com.insurance.insuranceCompany.model.FAQ;

@Repository
public class FAQRepositoryImp implements FAQRepository{
	
	@Autowired
	FAQDAO faqdao;
	
	@Override
	public List<FAQ> getAllFAQS() {
		return faqdao.getAllFAQS();
	}
}
