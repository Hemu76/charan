package com.insurance.insuranceCompany.repository;

import java.util.List;

import com.insurance.insuranceCompany.model.FAQ;

public interface FAQRepository {
	List<FAQ> getAllFAQS();
}
